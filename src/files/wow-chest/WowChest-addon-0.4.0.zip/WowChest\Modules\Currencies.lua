-- Saves gold, selected currencies and Shadowlands anima per character into WowChestDB.chars.
local _, ns = ...

local ANIMA_ID = 1813

local BAG_FIRST = Enum.BagIndex.Backpack
local BAG_LAST = Enum.BagIndex.ReagentBag or Enum.BagIndex.Bag_4

ns:AddDefaults("chars", {})
-- Chosen in the config window. Unticked ids are stored as false (not removed), otherwise the
-- defaults below would come back on the next login.
ns:AddDefaults("currencies", {
    tracked = {
        [824] = true,  -- Garrison Resources (Draenor)
        [1220] = true, -- Order Resources (Legion)
        [1560] = true, -- War Resources (BfA)
    },
})

local charKey

local function GetChar()
    if not charKey then
        local name = UnitName("player")
        charKey = name .. "-" .. GetNormalizedRealmName()
    end
    local chars = ns.db.chars
    chars[charKey] = chars[charKey] or {}
    local char = chars[charKey]
    char.currencies = char.currencies or {}
    char.anima = char.anima or { reservoir = {}, bags = { items = 0, value = 0 } }
    return char
end

local function Touch(char)
    char.updated = time()
    ns.ExportJSON()
end

local function SaveInfo(char)
    local _, class = UnitClass("player")
    char.name = UnitName("player")
    char.realm = GetRealmName()
    char.realmNormalized = GetNormalizedRealmName()
    char.class = class
    char.level = UnitLevel("player")
    char.guid = UnitGUID("player")
    Touch(char)
end

local function SaveGold()
    local char = GetChar()
    char.gold = GetMoney()
    Touch(char)
end

local function SaveCurrencies()
    local char = GetChar()
    -- Rebuilt every time so currencies unticked in the config stop being exported.
    char.currencies = {}
    for id, tracked in pairs(ns.db.currencies.tracked) do
        local info = tracked and C_CurrencyInfo.GetCurrencyInfo(id)
        if info and info.name and info.name ~= "" then
            char.currencies[id] = {
                name = info.name,
                qty = info.quantity,
                accountWide = info.isAccountWide or false,
                transferable = info.isAccountTransferable or false,
            }
        end
    end

    -- The anima reservoir amount belongs to the active covenant, so keep the last value seen for each.
    local covenantID = C_Covenants.GetActiveCovenantID()
    char.anima.activeCovenant = covenantID
    if covenantID and covenantID > 0 then
        local info = C_CurrencyInfo.GetCurrencyInfo(ANIMA_ID)
        local covenant = C_Covenants.GetCovenantData(covenantID)
        if info then
            char.anima.reservoir[covenantID] = {
                name = covenant and covenant.name,
                qty = info.quantity,
                updated = time(),
            }
        end
    end
    Touch(char)
end

-- Anima items say how much they deposit in their "Use:" line; take the first number from it.
local function GetAnimaValue(bag, slot)
    local data = C_TooltipInfo.GetBagItem(bag, slot)
    if not data or not data.lines then return 0 end
    for _, line in ipairs(data.lines) do
        local text = line.leftText
        if text and text:find(ITEM_SPELL_TRIGGER_ONUSE, 1, true) then
            local number = text:match("%d[%d,%.]*")
            if number then
                return tonumber((number:gsub("[,%.]", ""))) or 0
            end
        end
    end
    return 0
end

local function SaveBagAnima()
    local char = GetChar()
    local items, value = 0, 0
    for bag = BAG_FIRST, BAG_LAST do
        for slot = 1, C_Container.GetContainerNumSlots(bag) do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            if info and info.itemID and C_Item.IsAnimaItemByID(info.itemID) then
                items = items + info.stackCount
                value = value + GetAnimaValue(bag, slot) * info.stackCount
            end
        end
    end
    char.anima.bags = { items = items, value = value }
    Touch(char)
end

-- Currency and bag events come in bursts; wait for them to settle and stay out of combat.
local timers = {}
local ready = false -- character info (realm name) is only reliable after PLAYER_LOGIN
local function Debounce(key, fn)
    if not ready then return end
    if timers[key] then timers[key]:Cancel() end
    timers[key] = C_Timer.NewTimer(1, function()
        timers[key] = nil
        if InCombatLockdown() then
            Debounce(key, fn)
        else
            fn()
        end
    end)
end

ns:RegisterEvent("PLAYER_LOGIN", function()
    ready = true
    SaveInfo(GetChar())
    SaveGold()
    SaveCurrencies()
    SaveBagAnima()
end)
ns:RegisterEvent("PLAYER_LEVEL_UP", function() SaveInfo(GetChar()) end)
ns:RegisterEvent("PLAYER_MONEY", function() if ready then SaveGold() end end)

local function RefreshCurrencies() Debounce("currency", SaveCurrencies) end
local function RefreshBags() Debounce("bags", SaveBagAnima) end
local function RefreshAll()
    RefreshCurrencies()
    RefreshBags()
end

-- Direct currency changes.
ns:RegisterEvent("CURRENCY_DISPLAY_UPDATE", RefreshCurrencies)
ns:RegisterEvent("CHAT_MSG_CURRENCY", RefreshCurrencies)
-- Covenant joined/switched: the anima reservoir now belongs to another covenant.
ns:RegisterEvent("COVENANT_CHOSEN", RefreshCurrencies)
ns:RegisterEvent("COVENANT_SANCTUM_RENOWN_LEVEL_CHANGED", RefreshCurrencies)
-- Loot, quest turn-ins, vendors, mail and depositing anima items.
ns:RegisterEvent("BAG_UPDATE_DELAYED", RefreshBags)
ns:RegisterEvent("LOOT_CLOSED", RefreshAll)
ns:RegisterEvent("QUEST_TURNED_IN", RefreshAll)
ns:RegisterEvent("PLAYER_ENTERING_WORLD", RefreshAll)
ns:RegisterEvent("ZONE_CHANGED_NEW_AREA", RefreshAll)

-- Safety net in case an event is missed.
C_Timer.NewTicker(300, RefreshAll)

-- Used by the config window ---------------------------------------------

function ns.IsCurrencyTracked(id)
    return ns.db.currencies.tracked[id] == true
end

function ns.SetCurrencyTracked(id, tracked)
    ns.db.currencies.tracked[id] = tracked and true or false
    if ready then SaveCurrencies() end
end

-- The character's currency list grouped by its headers: { { name, items = { { id, name, icon } } } }.
-- Collapsed headers hide their children, so they are opened for the scan and closed again after.
function ns.ScanCurrencyList()
    local groups, reopened, seen = {}, {}, {}
    local index = 1
    while index <= C_CurrencyInfo.GetCurrencyListSize() do
        local info = C_CurrencyInfo.GetCurrencyListInfo(index)
        if info and info.isHeader then
            if not info.isHeaderExpanded then
                C_CurrencyInfo.ExpandCurrencyList(index, true)
                reopened[info.name] = true
            end
            table.insert(groups, { name = info.name, items = {} })
        elseif info and #groups > 0 then
            local id = info.currencyID
            if not id then
                local link = C_CurrencyInfo.GetCurrencyListLink(index)
                id = link and C_CurrencyInfo.GetCurrencyIDFromLink(link)
            end
            -- Anima is always tracked (per covenant), so it is not offered as a choice.
            if id and id ~= ANIMA_ID and not seen[id] then
                seen[id] = true
                table.insert(groups[#groups].items, { id = id, name = info.name, icon = info.iconFileID })
            end
        end
        index = index + 1
    end

    for i = C_CurrencyInfo.GetCurrencyListSize(), 1, -1 do
        local info = C_CurrencyInfo.GetCurrencyListInfo(i)
        if info and info.isHeader and reopened[info.name] then
            C_CurrencyInfo.ExpandCurrencyList(i, false)
        end
    end

    -- Tracked currencies this character has never earned still need a row to untick.
    local other = { name = OTHER, items = {} }
    for id, tracked in pairs(ns.db.currencies.tracked) do
        if tracked and not seen[id] then
            local info = C_CurrencyInfo.GetCurrencyInfo(id)
            if info and info.name and info.name ~= "" then
                table.insert(other.items, { id = id, name = info.name, icon = info.iconFileID })
            end
        end
    end
    if #other.items > 0 then
        table.insert(groups, other)
    end

    local result = {}
    for _, group in ipairs(groups) do
        if #group.items > 0 then
            table.insert(result, group)
        end
    end
    return result
end

local function FormatGold(copper)
    return GetMoneyString(copper or 0, true)
end

ns:RegisterCommand("gold", function()
    local total = 0
    local keys = {}
    for key in pairs(ns.db.chars) do table.insert(keys, key) end
    table.sort(keys)
    for _, key in ipairs(keys) do
        local char = ns.db.chars[key]
        total = total + (char.gold or 0)
        print(("  %s: %s"):format(key, FormatGold(char.gold)))
    end
    ns.Print("Total: " .. FormatGold(total))
end, { "gold - gold per character and total" })

ns:RegisterCommand("currencies", function()
    local char = GetChar()
    ns.Print(charKey .. ":")
    for _, c in pairs(char.currencies) do
        print(("  %s: %d"):format(c.name, c.qty))
    end
    for _, r in pairs(char.anima.reservoir) do
        print(("  Anima (%s): %d"):format(r.name or "?", r.qty))
    end
    print(("  Anima in bags: %d items, %d anima"):format(char.anima.bags.items, char.anima.bags.value))
end, { "currencies - tracked currencies for this character" })
