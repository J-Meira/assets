-- Turns NPC dialog sound off inside instances and back on when leaving.
local _, ns = ...

local CVAR = "Sound_EnableDialog"

ns:AddDefaults("dialog", {
    enabled = true,
    mutedByUs = false,
})

local pendingAfterCombat = false
-- Set when the player toggles manually inside an instance, so we don't override them until they leave.
local manualInThisInstance = false

local function Update()
    local settings = ns.db.dialog
    if InCombatLockdown() then
        pendingAfterCombat = true
        return
    end

    local inInstance = IsInInstance()
    if not inInstance then
        manualInThisInstance = false
    end
    if manualInThisInstance then return end

    if inInstance and settings.enabled then
        if GetCVar(CVAR) == "1" then
            SetCVar(CVAR, "0")
            settings.mutedByUs = true
            ns.Print("Dialog sound off (instance).")
        end
    elseif settings.mutedByUs then
        -- Only undo what we did; a manual "off" stays off.
        SetCVar(CVAR, "1")
        settings.mutedByUs = false
        ns.Print("Dialog sound on.")
    end
end

local function UpdateSoon()
    Update()
    -- Instance info can arrive late after a loading screen.
    C_Timer.After(1, Update)
end

ns:RegisterEvent("PLAYER_ENTERING_WORLD", UpdateSoon)
ns:RegisterEvent("ZONE_CHANGED_NEW_AREA", UpdateSoon)
ns:RegisterEvent("PLAYER_REGEN_ENABLED", function()
    if pendingAfterCombat then
        pendingAfterCombat = false
        Update()
    end
end)

ns:RegisterCommand("dialog", function(args)
    local arg = args[1] and args[1]:lower()
    if arg == "on" or arg == "off" then
        ns.ToggleSetting(ns.db.dialog, arg, "Auto dialog toggle")
        Update()
        return
    end
    -- Manual toggle, same as the old macro. Clearing the flag makes the choice stick.
    local newValue = GetCVar(CVAR) == "0" and "1" or "0"
    SetCVar(CVAR, newValue)
    ns.db.dialog.mutedByUs = false
    manualInThisInstance = IsInInstance()
    ns.Print("Dialog sound " .. (newValue == "1" and "on" or "off") .. ".")
end, {
    "dialog - toggle dialog sound now",
    "dialog on|off - auto mute dialog inside instances",
})
