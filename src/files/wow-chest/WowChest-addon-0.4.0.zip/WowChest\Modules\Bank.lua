-- When the bank opens, moves bag items into the bank tab where the same item already is.
local _, ns = ...

local BAG_FIRST = Enum.BagIndex.Backpack
local BAG_LAST = Enum.BagIndex.ReagentBag or Enum.BagIndex.Bag_4
local MAX_STEPS = 500

ns:AddDefaults("bank", {
    enabled = true,
    stackableOnly = false,
    ignore = {},
})

-- Bank tab bag IDs straight from the Enum, so new tabs are picked up automatically.
local function CollectTabs(prefix, bankType)
    local tabs = {}
    local i = 1
    while Enum.BagIndex[prefix .. i] do
        table.insert(tabs, { bag = Enum.BagIndex[prefix .. i], bankType = bankType })
        i = i + 1
    end
    return tabs
end

local TABS = CollectTabs("CharacterBankTab_", Enum.BankType.Character)
for _, tab in ipairs(CollectTabs("AccountBankTab_", Enum.BankType.Account)) do
    table.insert(TABS, tab)
end

local atBank = false
local interaction    -- Enum.PlayerInteractionType of the banker currently open
local running = false
local skipped = {}   -- "bag:slot" sources with no room (or failing) this run
local attempts = {}  -- "bag:slot" -> times we tried to move it
local lastMove
local moved = 0
local steps = 0

local function IsLocked(bag, slot)
    local info = C_Container.GetContainerItemInfo(bag, slot)
    return info and info.isLocked
end

-- Only deposit into the bank that is really open: a warband-only access point (the remote
-- warband bank) cannot reach the character bank even though its contents are still readable.
local function CanUseBank(bankType)
    if interaction == Enum.PlayerInteractionType.AccountBanker and bankType ~= Enum.BankType.Account then
        return false
    end
    if bankType == Enum.BankType.Account and C_PlayerInfo.HasAccountInventoryLock
        and not C_PlayerInfo.HasAccountInventoryLock() then
        -- Only one character at a time may use the warband bank.
        return false
    end
    if C_Bank.CanUseBank then
        return C_Bank.CanUseBank(bankType)
    end
    if C_Bank.CanViewBank then
        return C_Bank.CanViewBank(bankType)
    end
    return true
end

-- Maps itemID -> list of bank slots holding it, plus free slots per tab.
local function ScanBank()
    local items, free = {}, {}
    local usable = {
        [Enum.BankType.Character] = CanUseBank(Enum.BankType.Character),
        [Enum.BankType.Account] = CanUseBank(Enum.BankType.Account),
    }
    for _, tab in ipairs(TABS) do
        if usable[tab.bankType] then
            free[tab.bag] = {}
            for slot = 1, C_Container.GetContainerNumSlots(tab.bag) do
                local info = C_Container.GetContainerItemInfo(tab.bag, slot)
                if info then
                    items[info.itemID] = items[info.itemID] or {}
                    table.insert(items[info.itemID], {
                        bag = tab.bag, slot = slot, count = info.stackCount, bankType = tab.bankType,
                    })
                else
                    table.insert(free[tab.bag], slot)
                end
            end
        end
    end
    return items, free
end

-- Finds the next single move to make, or nil when nothing is left.
local function FindMove()
    local bankItems, free = ScanBank()
    local ignore = ns.db.bank.ignore
    local stackableOnly = ns.db.bank.stackableOnly
    for bag = BAG_FIRST, BAG_LAST do
        for slot = 1, C_Container.GetContainerNumSlots(bag) do
            local info = C_Container.GetContainerItemInfo(bag, slot)
            local key = bag .. ":" .. slot
            local targets = info and bankItems[info.itemID]
            local maxStack = targets and (C_Item.GetItemMaxStackSizeByID(info.itemID) or 1)
            if targets and not ignore[info.itemID] and not skipped[key] and not info.isLocked
                and not (stackableOnly and maxStack <= 1) then
                local location = ItemLocation:CreateFromBagAndSlot(bag, slot)
                for _, target in ipairs(targets) do
                    local allowed = target.bankType ~= Enum.BankType.Account
                        or C_Bank.IsItemAllowedInBankType(Enum.BankType.Account, location)
                    if allowed then
                        -- 1. Top up a partial stack of the same item.
                        if target.count < maxStack then
                            return { bag = bag, slot = slot, count = info.stackCount,
                                     toBag = target.bag, toSlot = target.slot,
                                     amount = math.min(info.stackCount, maxStack - target.count) }
                        end
                    end
                end
                for _, target in ipairs(targets) do
                    local allowed = target.bankType ~= Enum.BankType.Account
                        or C_Bank.IsItemAllowedInBankType(Enum.BankType.Account, location)
                    -- 2. A free slot in a tab that already holds this item.
                    local freeSlot = allowed and table.remove(free[target.bag])
                    if freeSlot then
                        return { bag = bag, slot = slot, count = info.stackCount,
                                 toBag = target.bag, toSlot = freeSlot, amount = info.stackCount }
                    end
                end
                skipped[key] = true
            end
        end
    end
end

local function Finish()
    running = false
    ClearCursor()
    if moved > 0 then
        ns.Print("Deposited items (" .. moved .. " move(s)).")
    end
end

local function Step()
    if not atBank or InCombatLockdown() or steps >= MAX_STEPS then
        Finish()
        return
    end
    steps = steps + 1

    if CursorHasItem() then
        ClearCursor()
    end

    -- Wait for the server to confirm the previous move, so free slots are read correctly.
    if lastMove and (IsLocked(lastMove.bag, lastMove.slot) or IsLocked(lastMove.toBag, lastMove.toSlot)) then
        C_Timer.After(0.2, Step)
        return
    end

    local move = FindMove()
    if not move then
        Finish()
        return
    end

    -- Give up on an item the server keeps rejecting.
    local key = move.bag .. ":" .. move.slot
    attempts[key] = (attempts[key] or 0) + 1
    -- (a big stack may legitimately need a few moves to fill several partial stacks)
    if attempts[key] > 10 then
        skipped[key] = true
        C_Timer.After(0, Step)
        return
    end

    if move.amount < move.count then
        C_Container.SplitContainerItem(move.bag, move.slot, move.amount)
    else
        C_Container.PickupContainerItem(move.bag, move.slot)
    end
    C_Container.PickupContainerItem(move.toBag, move.toSlot)
    lastMove = move
    moved = moved + 1

    local _, latency = GetNetStats()
    C_Timer.After(math.max(0.2, (latency or 0) / 1000), Step)
end

local function Start()
    if running or not ns.db.bank.enabled or InCombatLockdown() then return end
    running = true
    skipped = {}
    attempts = {}
    lastMove = nil
    moved = 0
    steps = 0
    -- Give the bank tabs a moment to load their contents.
    C_Timer.After(0.5, Step)
end

local BANK_TYPES = {
    [Enum.PlayerInteractionType.Banker] = true,
    [Enum.PlayerInteractionType.AccountBanker] = true,
}

ns:RegisterEvent("PLAYER_INTERACTION_MANAGER_FRAME_SHOW", function(_, interactionType)
    if BANK_TYPES[interactionType] then
        atBank = true
        interaction = interactionType
        Start()
    end
end)
ns:RegisterEvent("PLAYER_INTERACTION_MANAGER_FRAME_HIDE", function(_, interactionType)
    if BANK_TYPES[interactionType] then
        atBank = false
        interaction = nil
    end
end)

ns:RegisterCommand("bank", function(args)
    local arg = args[1] and args[1]:lower()
    if arg == "ignore" or arg == "unignore" then
        local itemID = args[2] and (tonumber(args[2]) or C_Item.GetItemInfoInstant(args[2]))
        if not itemID then
            ns.Print("Usage: /wc bank " .. arg .. " <item link or ID>")
            return
        end
        ns.db.bank.ignore[itemID] = (arg == "ignore") or nil
        ns.Print("Item " .. itemID .. (arg == "ignore" and " will not" or " will") .. " be deposited.")
    elseif arg == "list" then
        ns.Print("Ignored items:")
        for itemID in pairs(ns.db.bank.ignore) do
            print("  " .. (C_Item.GetItemNameByID(itemID) or "?") .. " (" .. itemID .. ")")
        end
    elseif arg == "now" then
        if atBank then Start() else ns.Print("Open the bank first.") end
    elseif arg == "stackable" then
        ns.db.bank.stackableOnly = not ns.db.bank.stackableOnly
        ns.Print("Deposit " .. (ns.db.bank.stackableOnly and "only stackable items." or "any item already in the bank."))
    else
        ns.ToggleSetting(ns.db.bank, arg, "Bank auto-deposit")
    end
end, {
    "bank on|off - auto deposit items already in the bank",
    "bank now - run the deposit again while the bank is open",
    "bank stackable - toggle depositing only stackable items",
    "bank ignore|unignore <item> - never deposit an item",
    "bank list - show ignored items",
})
