-- Save/load action bar layouts as named profiles, or export/import them as a text string.
local _, ns = ...

local PREFIX = "!WC1!"
local RANDOM_FAVORITE_MOUNT = 268435455

-- Bar numbers as shown in Blizzard's Settings -> Action Bars, mapped to their first action slot.
local BAR_START = {
    [1] = 1,   -- Main bar (page 1)
    [2] = 61,  -- MultiBarBottomLeft
    [3] = 49,  -- MultiBarBottomRight
    [4] = 25,  -- MultiBarRight
    [5] = 37,  -- MultiBarLeft
    [6] = 145, -- MultiBar5
    [7] = 157, -- MultiBar6
    [8] = 169, -- MultiBar7
}
local BUTTONS = 12

ns:AddDefaults("bars", {
    clearEmpty = true,
    profiles = {},
})

-- Capture ---------------------------------------------------------------

local function CaptureSlot(slot)
    local actionType, id, subType = GetActionInfo(slot)
    if not actionType then return false end

    if actionType == "macro" then
        local name = GetActionText(slot)
        local index = name and GetMacroIndexByName(name)
        if not index or index == 0 then return false end
        local _, icon, body = GetMacroInfo(index)
        return { type = "macro", name = name, icon = icon, body = body }
    end
    return { type = actionType, id = id, subType = subType }
end

local function CaptureBar(bar)
    local actions = {}
    for i = 1, BUTTONS do
        actions[i] = CaptureSlot(BAR_START[bar] + i - 1)
    end
    return actions
end

-- bars: list of bar numbers
local function Capture(bars)
    local data = { v = 1, bars = {} }
    for _, bar in ipairs(bars) do
        data.bars[bar] = CaptureBar(bar)
    end
    return data
end

-- Apply -----------------------------------------------------------------

local function FindFlyoutBookIndex(flyoutID)
    for line = 1, C_SpellBook.GetNumSpellBookSkillLines() do
        local info = C_SpellBook.GetSpellBookSkillLineInfo(line)
        for index = info.itemIndexOffset + 1, info.itemIndexOffset + info.numSpellBookItems do
            local item = C_SpellBook.GetSpellBookItemInfo(index, Enum.SpellBookSpellBank.Player)
            if item and item.itemType == Enum.SpellBookItemType.Flyout and item.actionID == flyoutID then
                return index
            end
        end
    end
end

local function PickupMacroByData(action)
    local index = GetMacroIndexByName(action.name)
    if index == 0 then
        -- Not on this character yet: create it as a character macro.
        local ok, newIndex = pcall(CreateMacro, action.name, action.icon, action.body, true)
        index = ok and newIndex or 0
    end
    if index and index > 0 then PickupMacro(index) end
end

-- Puts the action on the cursor; returns nothing if this character can't use it.
local function Pickup(action)
    local t, id = action.type, action.id
    if t == "spell" then
        C_Spell.PickupSpell(id)
    elseif t == "item" then
        if PlayerHasToy(id) then
            C_ToyBox.PickupToyBoxItem(id)
        else
            C_Item.PickupItem(id)
        end
    elseif t == "macro" then
        PickupMacroByData(action)
    elseif t == "summonmount" then
        if id == RANDOM_FAVORITE_MOUNT then
            C_MountJournal.Pickup(0)
        else
            local _, spellID = C_MountJournal.GetMountInfoByID(id)
            if spellID then C_Spell.PickupSpell(spellID) end
            if not GetCursorInfo() then
                -- Fallback: the journal picks up by list position (respects the journal's filters).
                for index = 1, C_MountJournal.GetNumDisplayedMounts() do
                    if C_MountJournal.GetDisplayedMountID(index) == id then
                        C_MountJournal.Pickup(index)
                        break
                    end
                end
            end
        end
    elseif t == "summonpet" then
        C_PetJournal.PickupPet(id)
    elseif t == "flyout" then
        local index = FindFlyoutBookIndex(id)
        if index then C_SpellBook.PickupSpellBookItem(index, Enum.SpellBookSpellBank.Player) end
    elseif t == "equipmentset" then
        local setID = C_EquipmentSet.GetEquipmentSetID(id)
        if setID then C_EquipmentSet.PickupEquipmentSet(setID) end
    end
end

local function Describe(action)
    if action.type == "macro" then return "macro " .. action.name end
    if action.type == "spell" then return C_Spell.GetSpellName(action.id) or ("spell " .. action.id) end
    if action.type == "item" then return C_Item.GetItemNameByID(action.id) or ("item " .. action.id) end
    return action.type .. " " .. tostring(action.id)
end

local function IsSame(slot, action)
    local actionType, id = GetActionInfo(slot)
    if action.type == "macro" then
        return actionType == "macro" and GetActionText(slot) == action.name
    end
    return actionType == action.type and id == action.id
end

local function ApplyBar(actions, bar, skipped)
    local start = BAR_START[bar]
    for i = 1, BUTTONS do
        local slot = start + i - 1
        local action = actions[i]
        ClearCursor()
        if not action then
            if ns.db.bars.clearEmpty and HasAction(slot) then
                PickupAction(slot)
                ClearCursor()
            end
        elseif not IsSame(slot, action) then
            Pickup(action)
            if GetCursorInfo() then
                PlaceAction(slot)
            else
                table.insert(skipped, Describe(action))
            end
        end
    end
    ClearCursor()
end

-- target: a bar number or nil for "every bar in the data, in its own place".
local function Apply(data, target)
    if InCombatLockdown() then
        ns.Print("Can't change action bars in combat.")
        return
    end
    if type(data) ~= "table" or type(data.bars) ~= "table" then
        ns.Print("Invalid action bar data.")
        return
    end

    local plan = {}
    if target then
        local source = data.bars[target]
        if not source then
            -- A single-bar export can be placed on any bar.
            local onlyBar, count = nil, 0
            for bar in pairs(data.bars) do onlyBar, count = bar, count + 1 end
            if count == 1 then source = data.bars[onlyBar] end
        end
        if not source then
            ns.Print("That data has no bar " .. target .. ".")
            return
        end
        plan[target] = source
    else
        plan = data.bars
    end

    local skipped = {}
    for bar, actions in pairs(plan) do
        if BAR_START[bar] then ApplyBar(actions, bar, skipped) end
    end
    if #skipped > 0 then
        ns.Print("Done. Skipped " .. #skipped .. ": " .. table.concat(skipped, ", "))
    else
        ns.Print("Done.")
    end
end

-- Encoding --------------------------------------------------------------

local function Encode(data)
    local serialized = C_EncodingUtil.SerializeCBOR(data)
    local compressed = C_EncodingUtil.CompressString(serialized, Enum.CompressionMethod.Deflate)
    return PREFIX .. C_EncodingUtil.EncodeBase64(compressed)
end

local function Decode(text)
    if not text or text:sub(1, #PREFIX) ~= PREFIX then return nil end
    local ok, decoded = pcall(C_EncodingUtil.DecodeBase64, text:sub(#PREFIX + 1))
    if not ok or not decoded then return nil end
    local decompressed
    ok, decompressed = pcall(C_EncodingUtil.DecompressString, decoded, Enum.CompressionMethod.Deflate)
    if not ok or not decompressed then return nil end
    local data
    ok, data = pcall(C_EncodingUtil.DeserializeCBOR, decompressed)
    return ok and data or nil
end

-- Commands --------------------------------------------------------------

-- Returns a list of bar numbers for "all"/nil, a single-item list for 1-8, or nil if invalid.
local function ParseBars(arg)
    if not arg or arg == "all" then
        local bars = {}
        for bar = 1, #BAR_START do table.insert(bars, bar) end
        return bars, nil
    end
    local bar = tonumber(arg)
    if bar and BAR_START[bar] then return { bar }, bar end
end

local function BarsUsage()
    ns.Print("Bar must be 1-8 or all.")
end

ns:RegisterCommand("bars", function(args)
    local sub = args[1] and args[1]:lower()
    local profiles = ns.db.bars.profiles

    if sub == "save" or sub == "load" then
        local name = args[2]
        if not name then
            ns.Print("Usage: /wc bars " .. sub .. " <name> [1-8|all]")
            return
        end
        local bars, target = ParseBars(args[3] and args[3]:lower())
        if not bars then return BarsUsage() end
        if sub == "save" then
            profiles[name] = Capture(bars)
            ns.Print("Saved profile '" .. name .. "'.")
        elseif not profiles[name] then
            ns.Print("No profile '" .. name .. "'.")
        else
            Apply(profiles[name], target)
        end
    elseif sub == "list" then
        ns.Print("Profiles:")
        for name, data in pairs(profiles) do
            local bars = {}
            for bar in pairs(data.bars) do table.insert(bars, bar) end
            table.sort(bars)
            print("  " .. name .. " (bars " .. table.concat(bars, ",") .. ")")
        end
    elseif sub == "delete" then
        if args[2] and profiles[args[2]] then
            profiles[args[2]] = nil
            ns.Print("Deleted profile '" .. args[2] .. "'.")
        else
            ns.Print("No profile '" .. tostring(args[2]) .. "'.")
        end
    elseif sub == "export" then
        local bars = ParseBars(args[2] and args[2]:lower())
        if not bars then return BarsUsage() end
        ns.ShowCopyFrame("Export action bars (Ctrl+C)", Encode(Capture(bars)))
    elseif sub == "import" then
        local bars, target = ParseBars(args[2] and args[2]:lower())
        if not bars then return BarsUsage() end
        ns.ShowCopyFrame("Paste action bars (Ctrl+V)", "", function(text)
            local data = Decode(text)
            if data then
                Apply(data, target)
            else
                ns.Print("Invalid import string.")
            end
        end)
    elseif sub == "clear" then
        local arg = args[2] and args[2]:lower()
        ns.db.bars.clearEmpty = (arg == "on") or (arg ~= "off" and not ns.db.bars.clearEmpty)
        ns.Print("Empty slots in the source " .. (ns.db.bars.clearEmpty and "will" or "won't") .. " clear the target.")
    else
        ns.Print("Usage: /wc bars save|load|list|delete|export|import|clear")
    end
end, {
    "bars save <name> [1-8|all] - save bars as a profile",
    "bars load <name> [1-8|all] - load a profile",
    "bars list | bars delete <name>",
    "bars export [1-8|all] - copy bars as a text string",
    "bars import [1-8|all] - paste a string onto your bars",
    "bars clear on|off - empty source slots clear target slots",
})
