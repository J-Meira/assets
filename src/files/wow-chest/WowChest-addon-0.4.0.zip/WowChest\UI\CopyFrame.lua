-- A small window with a multiline text box, used to copy (export) or paste (import) text.
local _, ns = ...

local frame

local function Create()
    frame = CreateFrame("Frame", "WowChestCopyFrame", UIParent, "BasicFrameTemplateWithInset")
    frame:SetSize(520, 320)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetMovable(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    -- Close with Escape.
    table.insert(UISpecialFrames, "WowChestCopyFrame")

    frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    frame.title:SetPoint("TOP", 0, -5)

    local scroll = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", 12, -32)
    scroll:SetPoint("BOTTOMRIGHT", -32, 44)

    local editBox = CreateFrame("EditBox", nil, scroll)
    editBox:SetMultiLine(true)
    editBox:SetMaxBytes(0)
    editBox:SetAutoFocus(false)
    editBox:SetFontObject(ChatFontNormal)
    editBox:SetWidth(470)
    editBox:SetScript("OnEscapePressed", function() frame:Hide() end)
    editBox:SetScript("OnEditFocusGained", function(self) self:HighlightText() end)
    scroll:SetScrollChild(editBox)
    frame.editBox = editBox

    local button = CreateFrame("Button", nil, frame, "UIPanelButtonTemplate")
    button:SetSize(120, 24)
    button:SetPoint("BOTTOMRIGHT", -12, 12)
    button:SetScript("OnClick", function()
        if frame.onAccept then
            local onAccept = frame.onAccept
            local text = strtrim(editBox:GetText())
            frame:Hide()
            onAccept(text)
        else
            frame:Hide()
        end
    end)
    frame.button = button
end

-- Without onAccept the window just shows text to copy; with it, the button reads the pasted text.
function ns.ShowCopyFrame(title, text, onAccept)
    if not frame then Create() end
    frame.title:SetText(title)
    frame.onAccept = onAccept
    frame.button:SetText(onAccept and "Import" or "Close")
    frame.editBox:SetText(text or "")
    frame:Show()
    frame.editBox:SetFocus()
    if text and text ~= "" then
        frame.editBox:HighlightText()
    end
end
