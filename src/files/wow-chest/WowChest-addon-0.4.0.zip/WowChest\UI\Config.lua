-- The options window: switches for the automations and the list of currencies to track.
local addonName, ns = ...

local WIDTH, HEIGHT = 420, 560
local ROW_HEIGHT = 22

local frame
local toggles = {}
local headerRows, currencyRows = {}, {}

-- A checkbox with its own label (the template's label key changed between game versions).
local function CreateCheck(parent, label, tooltip)
    local check = CreateFrame("CheckButton", nil, parent, "UICheckButtonTemplate")
    check:SetSize(24, 24)
    check.label = check:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    check.label:SetPoint("LEFT", check, "RIGHT", 4, 0)
    check.label:SetText(label)
    check:SetHitRectInsets(0, -check.label:GetStringWidth() - 6, 0, 0)
    if tooltip then
        check:SetScript("OnEnter", function(self)
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:SetText(label, 1, 1, 1)
            GameTooltip:AddLine(tooltip, nil, nil, nil, true)
            GameTooltip:Show()
        end)
        check:SetScript("OnLeave", GameTooltip_Hide)
    end
    return check
end

local function CreateTitle(parent, text)
    local title = parent:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetText(text)
    return title
end

-- Each automation switch reads and writes one saved setting.
local function AddToggle(anchor, label, tooltip, get, set, indent)
    local check = CreateCheck(frame, label, tooltip)
    check:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", indent or 0, -2)
    check:SetScript("OnClick", function(self)
        set(self:GetChecked())
        ns.RefreshConfig()
    end)
    check.get = get
    table.insert(toggles, check)
    return check
end

local function RefreshCurrencies()
    local content = frame.currencyContent
    for _, row in ipairs(headerRows) do row:Hide() end
    for _, row in ipairs(currencyRows) do row:Hide() end

    local y, headers, rows = 0, 0, 0
    for _, group in ipairs(ns.ScanCurrencyList()) do
        headers = headers + 1
        local header = headerRows[headers]
        if not header then
            header = content:CreateFontString(nil, "OVERLAY", "GameFontNormal")
            headerRows[headers] = header
        end
        header:ClearAllPoints()
        header:SetPoint("TOPLEFT", 4, -y - 4)
        header:SetText(group.name)
        header:Show()
        y = y + ROW_HEIGHT

        for _, item in ipairs(group.items) do
            rows = rows + 1
            local row = currencyRows[rows]
            if not row then
                row = CreateFrame("CheckButton", nil, content, "UICheckButtonTemplate")
                row:SetSize(22, 22)
                row.icon = row:CreateTexture(nil, "ARTWORK")
                row.icon:SetSize(16, 16)
                row.icon:SetPoint("LEFT", row, "RIGHT", 4, 0)
                row.label = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
                row.label:SetPoint("LEFT", row.icon, "RIGHT", 6, 0)
                row:SetHitRectInsets(0, -300, 0, 0)
                row:SetScript("OnClick", function(self)
                    ns.SetCurrencyTracked(self.currencyID, self:GetChecked())
                end)
                currencyRows[rows] = row
            end
            row.currencyID = item.id
            row.icon:SetTexture(item.icon)
            row.label:SetText(item.name)
            row:SetChecked(ns.IsCurrencyTracked(item.id))
            row:ClearAllPoints()
            row:SetPoint("TOPLEFT", 12, -y)
            row:Show()
            y = y + ROW_HEIGHT
        end
    end
    content:SetHeight(math.max(y, 1))
end

function ns.RefreshConfig()
    if not frame or not frame:IsShown() then return end
    for _, check in ipairs(toggles) do
        check:SetChecked(check.get())
    end
    -- "Only stackable" means nothing while the auto deposit itself is off.
    frame.stackable:SetEnabled(ns.db.bank.enabled)
    frame.stackable.label:SetFontObject(ns.db.bank.enabled and "GameFontHighlight" or "GameFontDisable")
    RefreshCurrencies()
end

local function Create()
    frame = CreateFrame("Frame", "WowChestConfigFrame", UIParent, "BasicFrameTemplateWithInset")
    frame:SetSize(WIDTH, HEIGHT)
    frame:SetPoint("CENTER")
    frame:SetFrameStrata("DIALOG")
    frame:SetMovable(true)
    frame:SetClampedToScreen(true)
    frame:EnableMouse(true)
    frame:RegisterForDrag("LeftButton")
    frame:SetScript("OnDragStart", frame.StartMoving)
    frame:SetScript("OnDragStop", frame.StopMovingOrSizing)
    frame:Hide()
    -- Close with Escape.
    table.insert(UISpecialFrames, "WowChestConfigFrame")

    local version = C_AddOns.GetAddOnMetadata(addonName, "Version") or ""
    frame.title = frame:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    frame.title:SetPoint("TOP", 0, -5)
    frame.title:SetText(addonName .. " " .. version)

    local automations = CreateTitle(frame, "Automations")
    automations:SetPoint("TOPLEFT", 16, -36)

    local dialog = AddToggle(automations, "Mute NPC dialog inside instances",
        "Turns dialog sound off when you enter an instance and back on when you leave.",
        function() return ns.db.dialog.enabled end,
        function(value) ns.db.dialog.enabled = value end)
    dialog:SetPoint("TOPLEFT", automations, "BOTTOMLEFT", 0, -6)

    local deposit = AddToggle(dialog, "Auto deposit at the bank",
        "When a bank opens, moves bag items into the tab that already holds the same item.",
        function() return ns.db.bank.enabled end,
        function(value) ns.db.bank.enabled = value end)

    frame.stackable = AddToggle(deposit, "Auto deposit only stackable items",
        "Leaves gear and other single items in your bags.",
        function() return ns.db.bank.stackableOnly end,
        function(value) ns.db.bank.stackableOnly = value end, 20)

    local minimap = AddToggle(frame.stackable, "Show minimap button",
        "The window also opens with /wc config and from the addon compartment.",
        function() return ns.db.minimap.show end,
        function(value)
            ns.db.minimap.show = value
            ns.UpdateMinimapButton()
        end, -20)

    local currencies = CreateTitle(frame, "Tracked currencies")
    currencies:SetPoint("TOPLEFT", minimap, "BOTTOMLEFT", 0, -12)

    local hint = frame:CreateFontString(nil, "OVERLAY", "GameFontDisableSmall")
    hint:SetPoint("TOPLEFT", currencies, "BOTTOMLEFT", 0, -4)
    hint:SetText("Saved for every character and sent to the app. Anima is always tracked.")

    local scroll = CreateFrame("ScrollFrame", nil, frame, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", hint, "BOTTOMLEFT", 0, -8)
    scroll:SetPoint("BOTTOMRIGHT", -34, 14)

    local content = CreateFrame("Frame", nil, scroll)
    content:SetSize(WIDTH - 60, 1)
    scroll:SetScrollChild(content)
    frame.currencyContent = content

    frame:SetScript("OnShow", ns.RefreshConfig)
end

function ns.ToggleConfig()
    if not frame then Create() end
    frame:SetShown(not frame:IsShown())
end

ns:RegisterCommand("config", ns.ToggleConfig, { "config - open the options window" })

-- Addon compartment entry (## AddonCompartmentFunc in the .toc).
function WowChest_OnAddonCompartmentClick()
    ns.ToggleConfig()
end
