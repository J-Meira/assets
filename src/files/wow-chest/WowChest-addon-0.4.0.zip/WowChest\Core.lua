-- Every addon file receives the addon name and a private table shared across its files.
local addonName, ns = ...

local defaults = {}
local initCallbacks = {}
local eventHandlers = {}
local commands = {}
local commandOrder = {}

function ns.Print(msg)
    print("|cff33ff99" .. addonName .. "|r: " .. tostring(msg))
end

-- Fill in any missing keys (recursively) so new defaults reach existing saved data.
local function ApplyDefaults(db, src)
    for key, value in pairs(src) do
        if type(value) == "table" then
            if type(db[key]) ~= "table" then db[key] = {} end
            ApplyDefaults(db[key], value)
        elseif db[key] == nil then
            db[key] = value
        end
    end
end

-- Modules declare their saved settings under WowChestDB[section].
function ns:AddDefaults(section, values)
    defaults[section] = values
end

-- Runs once the saved data is loaded and ns.db is available.
function ns:OnInit(fn)
    table.insert(initCallbacks, fn)
end

local frame = CreateFrame("Frame")
frame:SetScript("OnEvent", function(_, event, ...)
    for _, fn in ipairs(eventHandlers[event]) do
        fn(event, ...)
    end
end)

-- Several modules may listen to the same event.
function ns:RegisterEvent(event, fn)
    if not eventHandlers[event] then
        eventHandlers[event] = {}
        frame:RegisterEvent(event)
    end
    table.insert(eventHandlers[event], fn)
end

-- Registers "/wc <name> ..."; fn receives the rest of the input split into words.
function ns:RegisterCommand(name, fn, help)
    commands[name] = { fn = fn, help = help or {} }
    table.insert(commandOrder, name)
end

-- Shared helper for the "/wc <module> on|off" pattern.
function ns.ToggleSetting(settings, arg, label)
    if arg == "on" then
        settings.enabled = true
    elseif arg == "off" then
        settings.enabled = false
    else
        settings.enabled = not settings.enabled
    end
    ns.Print(label .. " " .. (settings.enabled and "enabled" or "disabled") .. ".")
end

-- Number keys (currency IDs, covenant IDs) would become arrays or fail in JSON; make every key a string.
local function ToJSONSafe(value)
    if type(value) ~= "table" then return value end
    local copy = {}
    for key, item in pairs(value) do
        copy[tostring(key)] = ToJSONSafe(item)
    end
    return copy
end

-- JSON copy of the character data, so the desktop companion never has to parse Lua.
function ns.ExportJSON()
    if not ns.db or not C_EncodingUtil or not C_EncodingUtil.SerializeJSON then return end
    local ok, json = pcall(C_EncodingUtil.SerializeJSON, {
        version = 1,
        exportedAt = time(),
        chars = ToJSONSafe(ns.db.chars or {}),
    })
    if ok then
        ns.db.export = json
    end
end

ns:RegisterEvent("PLAYER_LOGOUT", ns.ExportJSON)

ns:RegisterEvent("ADDON_LOADED", function(_, name)
    if name ~= addonName then return end
    WowChestDB = WowChestDB or {}
    ApplyDefaults(WowChestDB, defaults)
    ns.db = WowChestDB
    for _, fn in ipairs(initCallbacks) do
        fn()
    end
end)

local function PrintHelp()
    ns.Print("Commands:")
    for _, name in ipairs(commandOrder) do
        for _, line in ipairs(commands[name].help) do
            print("  /wc " .. line)
        end
    end
end

SLASH_WOWCHEST1 = "/wowchest"
SLASH_WOWCHEST2 = "/wc"
SlashCmdList.WOWCHEST = function(input)
    local args = {}
    -- Keep item links (which contain spaces) together as one argument.
    input = strtrim(input or "")
    local pos = 1
    while pos <= #input do
        local linkStart, linkEnd = input:find("|c.-|r", pos)
        local wordStart, wordEnd = input:find("%S+", pos)
        if not wordStart then break end
        if linkStart and linkStart == wordStart then
            table.insert(args, input:sub(linkStart, linkEnd))
            pos = linkEnd + 1
        else
            table.insert(args, input:sub(wordStart, wordEnd))
            pos = wordEnd + 1
        end
    end

    local name = args[1] and args[1]:lower()
    local command = name and commands[name]
    if not command then
        PrintHelp()
        return
    end
    table.remove(args, 1)
    command.fn(args)
end
